import Foundation

protocol PaywallView: AnyObject {
}

