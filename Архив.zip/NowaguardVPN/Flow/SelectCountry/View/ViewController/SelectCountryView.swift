import Foundation

protocol SelectCountryView: AnyObject {
    func reloadTable()
}

